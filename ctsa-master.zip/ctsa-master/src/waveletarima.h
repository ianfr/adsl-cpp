#ifndef WAVELETARIMA_H_
#define WAVELETARIMA_H_
#include "wavelib.h"
#include "ctsa.h"

#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif


#endif /* WAVELETARIMA_H_ */